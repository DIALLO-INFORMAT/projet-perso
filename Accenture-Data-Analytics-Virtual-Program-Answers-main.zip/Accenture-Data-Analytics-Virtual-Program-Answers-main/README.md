# Accenture-Data-Analytics-Virtual-Program-Answers

This repository consists of Accenture Data Analytics Virtual Experience Program Answers.

Link to youtube video : https://youtu.be/wzkT19GoQ0c

For Task 1 & Task 4 refer the video.
